export const devineLog = logThis => console.log(`Devine log: ${logThis}`);
